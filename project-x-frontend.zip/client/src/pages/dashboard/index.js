// Re-export the component
export { default } from './index.tsx';